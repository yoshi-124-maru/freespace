お手数ですが、DB作成と環境変数の設定をお願いします

DB作成名：freespace

環境変数
DB_URL
DB_USER
DB_PASS