package com.example.freespace.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "spaces")
public class Space {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // フリースペース名
    private String name;

    // 場所
    private String location;

    // 使用開始時間
    private String usageStartTime;

    // 使用終了時間
    private String usageEndTime;

    // 座席数
    private Integer capacity;

    // getter / setter
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getUsageStartTime() {
        return usageStartTime;
    }

    public void setUsageStartTime(String usageStartTime) {
        this.usageStartTime = usageStartTime;
    }

    public String getUsageEndTime() {
        return usageEndTime;
    }

    public void setUsageEndTime(String usageEndTime) {
        this.usageEndTime = usageEndTime;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }
}