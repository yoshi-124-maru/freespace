package com.example.freespace.controller;

import com.example.freespace.entity.Reservation;
import com.example.freespace.entity.Review;
import com.example.freespace.entity.User;
import com.example.freespace.repository.ReservationRepository;
import com.example.freespace.repository.ReviewRepository;
import com.example.freespace.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;

@Controller
public class ReviewController {

    private final ReviewRepository reviewRepository;
    private final ReservationRepository reservationRepository;
    private final UserRepository userRepository;

    public ReviewController(ReviewRepository reviewRepository,
                            ReservationRepository reservationRepository,
                            UserRepository userRepository) {
        this.reviewRepository = reviewRepository;
        this.reservationRepository = reservationRepository;
        this.userRepository = userRepository;
    }

    // =========================
    // レビュー入力画面
    // =========================
    @GetMapping("/review/new")
    public String reviewForm(@RequestParam Long reservationId,
                             Model model) {

        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("予約が見つかりません"));

        model.addAttribute("reservation", reservation);

        return "review_form";
    }

    // =========================
    // レビュー投稿処理
    // =========================
    @PostMapping("/review/create")
    public String create(@RequestParam Long reservationId,
                         @RequestParam Integer rating,
                         @RequestParam String comment,
                         HttpSession session,
                         Model model) {

        try {
            String email = (String) session.getAttribute("loginUser");

            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("ユーザーが見つかりません"));

            Reservation reservation = reservationRepository.findById(reservationId)
                    .orElseThrow(() -> new RuntimeException("予約が見つかりません"));

            Review review = new Review();
            review.setUser(user);
            review.setSpace(reservation.getSpace());
            review.setReservation(reservation);
            review.setRating(rating);
            review.setComment(comment);
            review.setCreatedAt(LocalDateTime.now());

            reviewRepository.save(review);

            return "redirect:/reservation/list";

        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            return "review_form";
        }
    }
}