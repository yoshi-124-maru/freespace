package com.example.freespace.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.freespace.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmail(String email);
    
}
