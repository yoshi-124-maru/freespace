package com.example.freespace.service;

import org.springframework.stereotype.Service;
import com.example.freespace.dto.UserRegisterRequest;
import com.example.freespace.entity.User;
import com.example.freespace.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.Optional;

@Service

public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder) {

        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public boolean register(UserRegisterRequest request) {

    if (userRepository.findByEmail(request.getEmail()).isPresent()) {
        return false;
    }

    User user = new User();

        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(
            passwordEncoder.encode(
                    request.getPassword()));
        user.setRole(request.getRole());
        // user.setRole("USER");

        userRepository.save(user);

        return true;
    }

    public User login(String email, String rawPassword) {

        Optional<User> userOpt = userRepository.findByEmail(email);

        if (userOpt.isEmpty()) {
            return null;
        }

        User user = userOpt.get();

        if (passwordEncoder.matches(rawPassword, user.getPassword())) {
            return user;
        }

        return null;
    }

    public void save(User user) {
        userRepository.save(user);
    }
}
