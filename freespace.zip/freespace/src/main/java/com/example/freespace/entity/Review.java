package com.example.freespace.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ★評価（1〜5）
    private Integer rating;

    // ★コメント
    private String comment;

    // ★投稿日時
    private LocalDateTime createdAt;

    // =========================
    // リレーション
    // =========================

    // 誰のレビューか
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    // どのスペースか
    @ManyToOne
    @JoinColumn(name = "space_id")
    private Space space;

    // どの予約か
    @ManyToOne
    @JoinColumn(name = "reservation_id")
    private Reservation reservation;

    // =========================
    // getter / setter
    // =========================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Space getSpace() {
        return space;
    }

    public void setSpace(Space space) {
        this.space = space;
    }

    public Reservation getReservation() {
        return reservation;
    }

    public void setReservation(Reservation reservation) {
        this.reservation = reservation;
    }
}