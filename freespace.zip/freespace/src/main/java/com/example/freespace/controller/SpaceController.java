package com.example.freespace.controller;

import com.example.freespace.entity.Space;
import com.example.freespace.service.SpaceService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class SpaceController {

    private final SpaceService spaceService;

    public SpaceController(SpaceService spaceService) {
        this.spaceService = spaceService;
    }

    // スペース登録画面表示
    @GetMapping("/admin/space/new")
    public String createForm() {
        return "space_create";
    }

    // スペース登録処理
    @PostMapping("/admin/space/create")
    public String create(Space space, RedirectAttributes redirectAttribute) {

        spaceService.save(space);

        redirectAttribute.addFlashAttribute("successMessage", "スペースを登録しました");

        return "redirect:/admin/space/list";
    }

    // スペース一覧表示
    @GetMapping("/admin/space/list")
    public String list(Model model) {

        model.addAttribute("spaces", spaceService.findAll());

        return "space_list";
    }
}