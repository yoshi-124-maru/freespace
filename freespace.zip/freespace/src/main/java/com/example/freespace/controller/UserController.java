package com.example.freespace.controller;

import com.example.freespace.dto.UserRegisterRequest;
import com.example.freespace.service.UserService;
import com.example.freespace.dto.LoginRequest;
import com.example.freespace.repository.UserRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.crypto.password.PasswordEncoder;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;
import org.springframework.ui.Model;

import com.example.freespace.entity.User;

@Controller
public class UserController {

    private final UserService userService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserController(UserService userService, UserRepository userRepository,PasswordEncoder passwordEncoder) {
        this.userService = userService;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/register")
    public String registerForm(Model model) {

    model.addAttribute("userRegisterRequest",
            new UserRegisterRequest());

    return "register";
    }

    @PostMapping("/register")
    public String register(
            @Valid UserRegisterRequest userRegisterRequest,
            BindingResult bindingResult,
            Model model) {

        if (bindingResult.hasErrors()) {
            return "register";
        }

        boolean result = userService.register(userRegisterRequest);

        if (!result) {
            model.addAttribute("duplicateError",
                    "このメールアドレスは既に登録されています");
            return "register";
        }

        model.addAttribute("successMessage",
                "ユーザー登録が完了しました");

        return "register";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(LoginRequest loginRequest, HttpSession session) {

        User user = userService.login(
                loginRequest.getEmail(),
                loginRequest.getPassword()
        );

        if (user != null) {
            session.setAttribute("loginUser", user.getEmail());
            session.setAttribute("role", user.getRole());

            session.setAttribute("loginName", user.getName());

            if ("ADMIN".equals(user.getRole())) {
                System.out.println("管理者ログイン");
            } else {
                System.out.println("一般ユーザーログイン");
            }
            return "redirect:/home";
        }

        return "login";
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @GetMapping("/profile")
    public String profileView(HttpSession session, Model model) {

        String email = (String) session.getAttribute("loginUser");

        if (email == null) {
            return "redirect:/login";
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("ユーザーが存在しません"));

        model.addAttribute("user", user);

        return "profile_view";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@RequestParam String name,
                                @RequestParam String email,
                                @RequestParam(required = false) String bio,
                                @RequestParam(required = false) String password,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {

        String loginEmail = (String) session.getAttribute("loginUser");

        User user = userRepository.findByEmail(loginEmail)
                .orElseThrow(() -> new RuntimeException("ユーザーが存在しません"));

        user.setName(name);
        user.setEmail(email);
        user.setBio(bio);

        if (password != null && !password.isEmpty()) {
            user.setPassword(passwordEncoder.encode(password));
        }

        userRepository.save(user);

        // email変更対応
        session.setAttribute("loginUser", email);
        session.setAttribute("loginName", user.getName());

        redirectAttributes.addFlashAttribute("successMessage", "プロフィールを更新しました");

        return "redirect:/profile";
    }

    @GetMapping("/profile/edit")
    public String profileEdit(HttpSession session, Model model) {

        String email = (String) session.getAttribute("loginUser");

        if (email == null) {
            return "redirect:/login";
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("ユーザーが存在しません"));

        model.addAttribute("user", user);

        return "profile_edit";
    }
}