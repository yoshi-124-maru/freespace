package com.example.freespace.repository;

import com.example.freespace.entity.Reservation;
import com.example.freespace.entity.Space;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    List<Reservation> findByUserEmail(String email);

    @Modifying
    @Query("update Reservation r set r.status = :status where r.id = :id")
    void updateStatus(Long id, String status);
    @Query("SELECT COALESCE(SUM(r.seatCount), 0) FROM Reservation r WHERE r.space = :space")
    int sumCapacityBySpace(@Param("space") Space space);
    List<Reservation> findBySpace(Space space);

    @Query("""
        SELECT r
        FROM Reservation r
        WHERE r.space = :space
          AND r.status IN :statusList
          AND r.reservationStartTime < :endTime
          AND r.reservationEndTime > :startTime
    """)
    List<Reservation> findOverlappingReservations(
            @Param("space") Space space,
            @Param("statusList") List<String> statusList,
            @Param("startTime") java.time.LocalDateTime startTime,
            @Param("endTime") java.time.LocalDateTime endTime
    );
}