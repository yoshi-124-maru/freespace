package com.example.freespace.controller;

import com.example.freespace.entity.Reservation;
import com.example.freespace.entity.Space;
import com.example.freespace.entity.User;
import com.example.freespace.repository.UserRepository;
import com.example.freespace.service.ReservationService;
import com.example.freespace.service.SpaceService;
import com.example.freespace.repository.ReviewRepository;
import com.example.freespace.repository.SpaceRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

@Controller
public class ReservationController {

    private final ReservationService reservationService;
    private final SpaceService spaceService;
    private final UserRepository userRepository;
    private final SpaceRepository spaceRepository;
    private final ReviewRepository reviewRepository;

    public ReservationController(ReservationService reservationService,
                                 SpaceService spaceService,
                                 UserRepository userRepository,
                                 SpaceRepository spaceRepository,
                                 ReviewRepository reviewRepository) {
        this.reservationService = reservationService;
        this.spaceService = spaceService;
        this.userRepository = userRepository;
        this.spaceRepository = spaceRepository;
        this.reviewRepository = reviewRepository;
    }

    // =========================
    // 予約画面表示
    // =========================
    @GetMapping("/reservation/new")
    public String reservationForm(
            @RequestParam(required = false) Long spaceId,
            @RequestParam(required = false) String reservationStartTime,
            @RequestParam(required = false) String reservationEndTime,
            Model model) {

        // =========================
        // スペース一覧
        // =========================
        List<Space> spaces = spaceService.findAll();
        model.addAttribute("spaces", spaces);

        model.addAttribute("reservation", new Reservation());

        // =========================
        // スペース取得（ここが修正ポイント）
        // =========================
        Space selectedSpace = null;

        if (spaceId != null) {
            selectedSpace = spaceRepository.findById(spaceId)
                    .orElseThrow(() -> new RuntimeException("Spaceなし: " + spaceId));
        }

        model.addAttribute("selectedSpace", selectedSpace);
        model.addAttribute("spaceId", spaceId);
        model.addAttribute("reservationStartTime", reservationStartTime);
        model.addAttribute("reservationEndTime", reservationEndTime);

        // =========================
        // 時間未入力なら空席出さない
        // =========================
        if (reservationStartTime == null || reservationEndTime == null
                || reservationStartTime.isEmpty() || reservationEndTime.isEmpty()) {

            model.addAttribute("available", null);
            return "reservation_create";
        }

        // =========================
        // 変換
        // =========================
        LocalDateTime start = LocalDateTime.parse(reservationStartTime);
        LocalDateTime end = LocalDateTime.parse(reservationEndTime);

        // =========================
        // 空席計算
        // =========================
        int available = reservationService.getAvailableSeats(
                selectedSpace,
                start,
                end
        );

        model.addAttribute("available", available);

        return "reservation_create";
    }

    // =========================
    // 予約登録処理
    // =========================
    @PostMapping("/reservation/create")
    public String create(

            @RequestParam Long spaceId,
            @RequestParam String reservationStartTime,
            @RequestParam String reservationEndTime,
            @RequestParam Integer seatCount,
            HttpSession session,
            Model model,
            RedirectAttributes redirectAttributes
    ) {

        try {
            String email = (String) session.getAttribute("loginUser");

            if (email == null) {
                return "redirect:/login";
            }

            User user = userRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("ユーザーが存在しません"));

            Space space = spaceRepository.findById(spaceId)
                    .orElse(null);

            if (space == null) {
                model.addAttribute("error", "スペースが見つかりません");
                model.addAttribute("spaces", spaceService.findAll());
                model.addAttribute("selectedSpace", null);
                return "reservation_create";
            }

            LocalDateTime start = LocalDateTime.parse(reservationStartTime);
            LocalDateTime end = LocalDateTime.parse(reservationEndTime);

            Reservation reservation = new Reservation();
            reservation.setUser(user);
            reservation.setSpace(space);
            reservation.setReservationStartTime(start);
            reservation.setReservationEndTime(end);
            reservation.setSeatCount(seatCount);

            reservationService.validateAvailability(
                    space,
                    reservation.getReservationStartTime(),
                    reservation.getReservationEndTime(),
                    reservation.getSeatCount()
            );
            reservationService.save(reservation, space);

            redirectAttributes.addFlashAttribute("successMessage", "予約が完了しました");

            return "redirect:/reservation/list";

        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("spaces", spaceService.findAll());
            model.addAttribute("selectedSpace", null);
            return "reservation_create";
        }
    }

    @GetMapping("/reservation/list")
    public String list(HttpSession session, Model model) {

        String email = (String) session.getAttribute("loginUser");

        if (email == null) {
            return "redirect:/login";
        }

        List<Reservation> reservations =
                reservationService.findByUserEmail(email);

        model.addAttribute("reservations", reservations);

        Map<Long, Boolean> reviewedMap = new HashMap<>();

        for (Reservation r : reservations) {
            boolean exists = reviewRepository.findByReservationId(r.getId()).isPresent();
            reviewedMap.put(r.getId(), exists);
        }

        model.addAttribute("reviewedMap", reviewedMap);    
            
        return "reservation_list";
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(HttpSession session, Model model) {

        String email = (String) session.getAttribute("loginUser");

        if (email == null) {
            return "redirect:/login";
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("ユーザーが存在しません"));

        if (!"ADMIN".equals(user.getRole())) {
            return "redirect:/home";
        }

        model.addAttribute("reservations", reservationService.findAll());

        return "admin_dashboard";
    }

    @PostMapping("/admin/reservation/approve")
    public String approve(@RequestParam Long reservationId) {
        reservationService.approve(reservationId);
        return "redirect:/admin/dashboard";
    }

    @PostMapping("/admin/reservation/reject")
    public String reject(@RequestParam Long reservationId) {
        reservationService.reject(reservationId);
        return "redirect:/admin/dashboard";
    }
}