package com.example.freespace.service;

import com.example.freespace.entity.Space;
import com.example.freespace.repository.SpaceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SpaceService {

    private final SpaceRepository spaceRepository;

    public SpaceService(SpaceRepository spaceRepository) {
        this.spaceRepository = spaceRepository;
    }

    // スペース登録
    public void save(Space space) {
        spaceRepository.save(space);
    }

    // スペース一覧取得
    public List<Space> findAll() {
        return spaceRepository.findAll();
    }
}