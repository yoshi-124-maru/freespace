package com.example.freespace.service;

import com.example.freespace.entity.Reservation;
import com.example.freespace.entity.Space;
import com.example.freespace.repository.ReservationRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;

import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ReservationService {

    private final ReservationRepository reservationRepository;

    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    // 予約登録
    public void save(Reservation reservation, Space space) {

        validateAvailability(
        space,
        reservation.getReservationStartTime(),
        reservation.getReservationEndTime(),
        reservation.getSeatCount()
);

        LocalTime spaceStart = LocalTime.parse(space.getUsageStartTime());
        LocalTime spaceEnd = LocalTime.parse(space.getUsageEndTime());

        LocalTime resStart = reservation.getReservationStartTime().toLocalTime();
        LocalTime resEnd = reservation.getReservationEndTime().toLocalTime();

        // 🔥 ルールチェック
        boolean isOutside =
                resStart.isBefore(spaceStart) ||
                resEnd.isAfter(spaceEnd) ||
                resStart.isAfter(resEnd); // 念のため

        if (isOutside) {
            throw new IllegalArgumentException("使用可能時間外のため予約できません");
        }
        reservation.setStatus("未承認"); // 初期状態
        reservationRepository.save(reservation);
    }

    // 予約一覧取得
    public List<Reservation> findAll() {
        return reservationRepository.findAll();
    }

    public List<Reservation> findByUserEmail(String email) {
        return reservationRepository.findByUserEmail(email);
    }

    @Transactional
    public void approve(Long reservationId) {
        reservationRepository.updateStatus(reservationId, "承認済");
    }

    @Transactional
    public void reject(Long reservationId) {
        reservationRepository.updateStatus(reservationId, "却下済");
    }

    public int getAvailableSeats(Space space) {
        List<Reservation> reservations =
                reservationRepository.findBySpace(space);

        int reservedCount = 0;

        for (Reservation r : reservations) {
            int seat = (r.getSeatCount() == null) ? 1 : r.getSeatCount();
            reservedCount += seat;
        }

        return space.getCapacity() - reservedCount;
    }

    public int getAvailableSeats(Space space,
                             LocalDateTime targetStart,
                             LocalDateTime targetEnd) {

        // =========================
        // 未入力チェック
        // =========================
        if (targetStart == null || targetEnd == null) {
            return space.getCapacity();
        }

        // =========================
        // 対象ステータス
        // =========================
        List<String> statusList = List.of("未承認", "承認済");

        // =========================
        // DBで「重なってる予約だけ取得」
        // =========================
        List<Reservation> reservations =
                reservationRepository.findOverlappingReservations(
                        space,
                        statusList,
                        targetStart,
                        targetEnd
                );

        // =========================
        // 合計計算
        // =========================
        int reservedCount = 0;

        for (Reservation r : reservations) {

            int seat = (r.getSeatCount() == null) ? 1 : r.getSeatCount();
            reservedCount += seat;
        }

        // =========================
        // 空席計算
        // =========================
        int result = space.getCapacity() - reservedCount;

        return Math.max(result, 0);
    }
    public void validateAvailability(
            Space space,
            LocalDateTime start,
            LocalDateTime end,
            int requestSeats
    ) {

        int available = getAvailableSeats(space, start, end);

        if (available < requestSeats) {
            throw new IllegalArgumentException("空席が不足しています");
        }
    }
}