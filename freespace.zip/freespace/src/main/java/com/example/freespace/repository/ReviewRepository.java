package com.example.freespace.repository;

import com.example.freespace.entity.Review;
import com.example.freespace.entity.Space;
import com.example.freespace.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    // ★スペースごとのレビュー取得
    List<Review> findBySpace(Space space);

    // ★ユーザーごとのレビュー取得
    List<Review> findByUser(User user);

    // ★予約ごとのレビュー取得（重複防止とかに使える）
    Optional<Review> findByReservationId(Long reservationId);
}